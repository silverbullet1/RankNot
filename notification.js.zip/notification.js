alert("Hello");
$.ajax({
             type: "GET",
             url: "/api/rankings/APRIL16?filterBy=Institution%3DIndian%20Institute%20of%20Information%20Technology%2C%20Allahabad&order=asc&sortBy=rank" , 
             datatype: 'jsonp',
             async : true,
             xhrFields: {
               withCredentials: true
            },
            crossDomain: true,
             success: function(res)
             { 
		var totalUsers = res.selectedItems;
		var totalPages = Math.floor(totalUsers / 50);
		var user = [];
		//console.log(size);
		for (var pages = 1; pages<=totalPages; pages++) //Complete pages
		{
			url = '/api/rankings/APRIL16?filterBy=Institution%3DIndian%20Institute%20of%20Information%20Technology%2C%20Allahabad&order=asc&sortBy=rank&page=' + pages.toString();
			window.history.replaceState("object or string", "Next Page", url);
			
			for(var i=0;i<50;i++)
			{
				person = {}
				person.username = res.list[i].user_handle
				person.score = res.list[i].score;
				person.rank = res.list[i].rank;
				user.push(person);
				//console.log(user[i].username);
			}
				console.log(window.location.href);
		}
		totalPages+=1;
		for(var i=0;i<totalUsers%50;i++) //The residue left after division
			{
				url = '/api/rankings/APRIL16?filterBy=Institution%3DIndian%20Institute%20of%20Information%20Technology%2C%20Allahabad&order=asc&sortBy=rank&page=' + totalPages.toString();
				window.history.replaceState("object or string", "Last Page", url);
				person = {}
				person.username = res.list[i].user_handle
				person.score = res.list[i].score;
				person.rank = res.list[i].rank;
				user.push(person);
				//console.log(user[i].username);
			}
				console.log(window.location.href);

alert( 'YESS' );
               }});